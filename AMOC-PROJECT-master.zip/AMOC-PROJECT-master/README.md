# AMOC-PROJECT
mock website for the competition
